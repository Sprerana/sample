<?php
$cmd1= "\"c:\Program Files\R\R-3.5.2\bin\Rscript\" sample1.R";
	echo exec($cmd1);
	echo "<img src='temp.png'>";
	?>