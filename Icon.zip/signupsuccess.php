<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="display: table;margin: 0 auto;"><br><br><br><br><br><br><br><br><br><br><br><br>
	<span style="font-size: 30px;color: #164285;">Registration Successful</span><br><br>
	<span style="font-size: 20px;display: table;margin: 0 auto;">Please &nbsp;<a href="login.php" style="text-decoration: none;font-size: 25px;color: #D9102E;">Login</a></span>
</body>
</html>