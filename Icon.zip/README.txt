Team- instance@6

industries_data.php - To view total details of the industries as well as high consumption table.(admin )

userstable.php - E-mail Alerts (admin)

Open file index.php to show the starting page of the web application.

After logging in home page will be shown with an option of map link which helps you navigate the data of industries in a geographical format. After that we have to come back to the main page, where there will be options such as profile, logout.

The profile has the complete personal details of the user industry data as well as pictorial representation of past data in a line graph format(monthlly extraction sensor data) and make future predictions by taking the past ground water data into consideration. This is handled by admin to show different thing.

Every page needs net connection as well as the respective database connection.

industry(1).sql is the database which contains the map plotting information .

leafletjs links are kept such that the map is loaded on the web site whcih requires net connection.

canvasjs is used to plot the graphs.