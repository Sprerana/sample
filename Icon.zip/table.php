<table class="industryTable">
<tfoot>
<tr>


</tr>
</tfoot>
<tbody>
<tr>
<td>Name</td>
<td id="name"></td>
</tr>
<tr>
<td id="limit">Limit</td>
<td>c</td>
</tr>
<tr>
<td id="extraction">Extraction</td>
<td></td>
</tr>
<tr>
<td>Recharge</td>
<td id="recharge"></td>
</tr>
</tbody>
</table>