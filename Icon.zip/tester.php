<?php

include 'includes/db.php';
$sql="SELECT * FROM users WHERE username='{$_SESSION['username']}'";
$result=mysqli_query($conn,$sql);
$resultcheck=mysqli_num_rows($result);
if ($resultcheck == 1) {
	$row = mysqli_fetch_assoc($result);
}
$mon=explode(",",$row["year"]);
for($i=0;$i<sizeof($mon);$i++)
{
	$chart[$i]=$mon[$i];
}

$dataPoints = array(
	array("y" => $chart[0], "label" => "Jan"),
	array("y" => $chart[1], "label" => "feb"),
	array("y" => $chart[2], "label" => "March"),
	array("y" => $chart[3], "label" => "April"),
	array("y" => $chart[4], "label" => "May"),
	array("y" => $chart[5], "label" => "June"),
	array("y" => $chart[6], "label" => "July"),
	array("y" => $chart[7], "label" => "Aug"),
	array("y" => $chart[8], "label" => "Sep"),
	array("y" => $chart[9], "label" => "Oct"),
	array("y" => $chart[10], "label" => "Nov"),
	array("y" => $chart[11], "label" => "Dec"),

);
 ?>
<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function () {
 var chart = new CanvasJS.Chart("chartContainer", {
	title: {
		text: ""
	},
	axisY: {
		title: "extraction in m3"
	},
	data: [{
		type: "line",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 }
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html> 
