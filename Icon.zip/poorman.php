
<?php
$cmd = "\"c:\Program Files\R\R-3.5.2\bin\Rscript\" sample.R";


	echo exec($cmd);
	echo "<img src='line_chart.jpg'>";

?>
